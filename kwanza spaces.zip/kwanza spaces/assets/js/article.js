/* ============================================
   KWANZA SPACES - Single Article JavaScript
   kwanza.africa
   ============================================ */

(function () {
  'use strict';

  /* ── READING PROGRESS BAR ── */
  var progressBar = document.getElementById('progress');
  if (progressBar) {
    window.addEventListener('scroll', function () {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      if (h > 0) {
        progressBar.style.width = (window.scrollY / h * 100) + '%';
      }
    }, { passive: true });
  }

})();
