/* ============================================
   KWANZA SPACES - Main JavaScript
   kwanza.africa
   ============================================ */

(function () {
  'use strict';

  /* ── NAV SCROLL SHADOW ── */
  const nav = document.getElementById('mainNav');
  if (nav) {
    window.addEventListener('scroll', function () {
      nav.classList.toggle('scrolled', window.scrollY > 20);
    }, { passive: true });
  }

  /* ── MOBILE NAV TOGGLE ── */
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      navLinks.classList.toggle('open');
      navToggle.classList.toggle('active');
    });
  }

  /* ── SCROLL REVEAL (IntersectionObserver) ── */
  var revealSelectors = '.reveal, .reveal-left, .reveal-right, .reveal-scale, .reveal-stagger';
  var revealEls = document.querySelectorAll(revealSelectors);

  if (revealEls.length && 'IntersectionObserver' in window) {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    revealEls.forEach(function (el) {
      revealObserver.observe(el);
    });
  }

  /* ── SMOOTH SCROLL FOR ANCHOR LINKS ── */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var targetSelector = this.getAttribute('href');
      if (targetSelector === '#') return;
      var target = document.querySelector(targetSelector);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
        // Close mobile nav if open
        if (navLinks) navLinks.classList.remove('open');
        if (navToggle) navToggle.classList.remove('active');
      }
    });
  });

  /* ── HERO ANIMATION TRIGGER ── */
  var heroEl = document.querySelector('.hero-animate');
  if (heroEl) {
    heroEl.classList.add('hero-animate');
  }

  /* ── PARALLAX ON FLOATING ORBS ── */
  var orbs = document.querySelectorAll('.why-float, .hero-geo');
  if (orbs.length && window.innerWidth > 900) {
    window.addEventListener('mousemove', function (e) {
      var x = (e.clientX / window.innerWidth - 0.5) * 2;
      var y = (e.clientY / window.innerHeight - 0.5) * 2;
      orbs.forEach(function (orb, i) {
        var speed = (i + 1) * 6;
        orb.style.transform = 'translate(' + (x * speed) + 'px, ' + (y * speed) + 'px)';
      });
    }, { passive: true });
  }

  /* ── COUNTER ANIMATION (for stats) ── */
  var statVals = document.querySelectorAll('.stat-val');
  if (statVals.length && 'IntersectionObserver' in window) {
    var counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          counterObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    statVals.forEach(function (el) {
      counterObserver.observe(el);
    });
  }

  function animateCounter(el) {
    var text = el.textContent;
    var match = text.match(/^(\d+)/);
    if (!match) return;

    var target = parseInt(match[1], 10);
    var suffix = text.replace(match[1], '');
    var duration = 1200;
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      var current = Math.floor(eased * target);
      el.innerHTML = current + suffix;
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.innerHTML = target + suffix;
      }
    }

    requestAnimationFrame(step);
  }

  /* ── MAGNETIC BUTTON EFFECT ── */
  var magneticBtns = document.querySelectorAll('.btn-primary, .btn-outline, .plan-cta, .nav-cta');
  if (window.innerWidth > 900) {
    magneticBtns.forEach(function (btn) {
      btn.addEventListener('mousemove', function (e) {
        var rect = btn.getBoundingClientRect();
        var x = e.clientX - rect.left - rect.width / 2;
        var y = e.clientY - rect.top - rect.height / 2;
        btn.style.transform = 'translate(' + (x * 0.15) + 'px, ' + (y * 0.15) + 'px)';
      });

      btn.addEventListener('mouseleave', function () {
        btn.style.transform = '';
      });
    });
  }

})();
