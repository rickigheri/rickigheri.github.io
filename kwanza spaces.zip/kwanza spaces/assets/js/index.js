/* ============================================
   KWANZA SPACES - Homepage JavaScript
   kwanza.africa
   ============================================ */

(function () {
  'use strict';

  /* ── HERO CARD TILT ON MOUSE ── */
  var heroCards = document.querySelectorAll('.hero-card');
  if (heroCards.length && window.innerWidth > 900) {
    var heroRight = document.querySelector('.hero-right');
    if (heroRight) {
      heroRight.addEventListener('mousemove', function (e) {
        var rect = heroRight.getBoundingClientRect();
        var x = (e.clientX - rect.left) / rect.width - 0.5;
        var y = (e.clientY - rect.top) / rect.height - 0.5;

        heroCards.forEach(function (card, i) {
          var mult = i === 0 ? 1 : -1;
          card.style.transform = 'translate(' + (x * 12 * mult) + 'px, ' + (y * 12 * mult) + 'px) scale(1)';
        });
      });

      heroRight.addEventListener('mouseleave', function () {
        heroCards.forEach(function (card) {
          card.style.transform = '';
        });
      });
    }
  }

})();
