/* ============================================
   KWANZA SPACES - Articles Listing JavaScript
   kwanza.africa
   ============================================ */

(function () {
  'use strict';

  /* ── FILTER BUTTONS ── */
  var filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      filterBtns.forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });

})();
