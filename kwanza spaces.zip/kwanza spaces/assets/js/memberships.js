/* ============================================
   KWANZA SPACES - Memberships JavaScript
   kwanza.africa
   ============================================ */

(function () {
  'use strict';

  /* ── ACTIVE PLAN NAV ON SCROLL ── */
  var sections = document.querySelectorAll('.plan-section, #addons, #compare');
  var navItems = document.querySelectorAll('.pn-item');

  if (sections.length && navItems.length) {
    window.addEventListener('scroll', function () {
      var current = '';
      sections.forEach(function (s) {
        if (window.scrollY >= s.offsetTop - 160) {
          current = s.id;
        }
      });
      navItems.forEach(function (item) {
        item.classList.toggle('active', item.getAttribute('href') === '#' + current);
      });
    }, { passive: true });
  }

})();
